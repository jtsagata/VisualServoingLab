function qc = conjq( q )
	
 qc = [ q(1);  -q(2:4) ];