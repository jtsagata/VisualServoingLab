function xc = conjdualqsimple( x )
	
xc = [ x(1);  -x(2:4);  x(5);  -x(6:8) ];
	
	  